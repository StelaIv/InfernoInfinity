package com.company.interfaces;

import java.io.IOException;

public interface IReader {

    String readLine() throws IOException;
}
