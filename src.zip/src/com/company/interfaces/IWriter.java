package com.company.interfaces;

public interface IWriter {

    void write(String output);
}
