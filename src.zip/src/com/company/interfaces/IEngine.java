package com.company.interfaces;

import java.io.IOException;

public interface IEngine {

    void run() throws IOException;
}
